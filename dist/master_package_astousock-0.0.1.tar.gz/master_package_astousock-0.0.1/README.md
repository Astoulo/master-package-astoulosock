SM Lib - Proclame la bonne parole de sieurs Sam et Max
========================================================

Il existe 2 modules dans ce package:
    ---- annee_bissextile pour retourner si la valeur saisie est bissextile ou pas 
    -----table_multiplication pour retourner la table de multiplication de la valeur saisie.


Vous pouvez l'installer avec pip:

    pip install master_package

Exemple d'usage:

    >>> from .annee_bissextile import annee_bissextile
    >>> annee_bissextile()

    >>> from .table_multiplication import multiplication
    >>> multiplication()
    

Ce code est sous licence WTFPL.